# wvp-pro-assist

wvp-pro-assist是wvp-pro的辅助录像程序，也可单独跟zlm一起使用，提供录像控制,录像合并下载接口
