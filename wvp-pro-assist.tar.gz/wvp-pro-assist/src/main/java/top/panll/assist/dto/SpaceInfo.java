package top.panll.assist.dto;

public class SpaceInfo {
    private long total;
    private long free;

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public long getFree() {
        return free;
    }

    public void setFree(long free) {
        this.free = free;
    }

}
